import 'dart:io';

import 'package:LustyLabs/components/buttonWithIcon.dart';
import 'package:LustyLabs/components/settingsSheet.dart';
import 'package:LustyLabs/models/VideoModel.dart';
import 'package:LustyLabs/screens/videoStreaming.dart';
import 'package:LustyLabs/theme.dart';
import 'package:animated_card/animated_card.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:infinite_listview/infinite_listview.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<VideoModel> videosList = [];
  List<VideoModel> videosListToDisplay = [];

  @override
  void initState() {
    super.initState();

    _fetchLatestVideos();
  }

  @override
  Widget build(BuildContext context) {
    final themex = Theme.of(context);

    return SafeArea(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).requestFocus(new FocusNode()),
        child: Container(
          color: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                SizedBox(height: MediaQuery.of(context).size.height * 0.01),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // # Title "Lusty Labs" with underline
                    Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 30, horizontal: 10),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // # Lusty Labs heading
                          Text(
                            "Lusty Labs",
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                              fontSize: 25,
                            ),
                          ),
                          SizedBox(height: 2),
                          // # Underline
                          Container(
                            width: 50,
                            height: 4,
                            color: Colors.black,
                          ),
                        ],
                      ),
                    ),
                    // # Settings button
                    Padding(
                      padding: EdgeInsets.only(right: 10),
                      child: ButtonWithIcon(
                        Icons.more_horiz,
                        onPressed: () => showModalBottomSheet(
                          context: context,
                          backgroundColor: Colors.transparent,
                          builder: (context) {
                            return SettingsSheet();
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                // # Search field
                Container(
                  decoration: BoxDecoration(
                    color: Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      SizedBox(width: 15),
                      SvgPicture.asset("assets/svg/SearchIcon.svg"),
                      SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          onChanged: (value) {
                            if (value.length > 0) {
                              final List<VideoModel> tempVideosList = [];

                              videosList.forEach((video) {
                                if (video.title != null &&
                                    video.title
                                        .toString()
                                        .toLowerCase()
                                        .contains(value.toLowerCase())) {
                                  tempVideosList.add(video);
                                }
                              });

                              setState(() {
                                videosListToDisplay = tempVideosList;
                              });
                            } else {
                              setState(() {
                                videosListToDisplay = videosList;
                              });
                            }
                          },
                          style: themex.textTheme.bodyText2,
                          decoration: InputDecoration(
                            hintText: "Search videos",
                            hintStyle: themex.textTheme.caption,
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(vertical: 15),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30),
                // # Videos list
                videosListToDisplay.length > 0
                    ? Expanded(
                        child: ListView.builder(
                          itemCount: videosListToDisplay.length,
                          itemBuilder: (BuildContext ctxt, int index) {
                            return VideoCard(
                              video: videosListToDisplay[index],
                            );
                          },
                        ),
                      )
                    : Align(
                        alignment: Alignment.center,
                        child: Container(
                          margin: EdgeInsets.only(top: 20),
                          child: Text(
                            "No videos to show!",
                            style: TextStyle(
                              color: Color(0xFF999999),
                              fontStyle: FontStyle.italic,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _fetchLatestVideos() {
    FirebaseFirestore.instance
        .collection("videos")
        .orderBy("upload_date", descending: true)
        .limit(10)
        .snapshots()
        .listen((event) {
      videosList = [];
      videosListToDisplay = [];
      event.docs.forEach((element) {
        final videoDetails = element.data();

        setState(() {
          videosList.add(
            VideoModel(
              uid: videoDetails["uid"],
              thumbnailUrl: videoDetails["thumbnail_url"],
              url: videoDetails["video_url"],
              title: videoDetails["title"],
              owner: videoDetails["owner"],
              viewsCount: videoDetails["views_count"],
              duration: videoDetails["duration"],
              description: videoDetails['description'],
              uploadDate: (videoDetails["upload_date"] as Timestamp).toDate(),
            ),
          );
          videosListToDisplay.add(
            VideoModel(
              uid: videoDetails["uid"],
              thumbnailUrl: videoDetails["thumbnail_url"],
              url: videoDetails["video_url"],
              title: videoDetails["title"],
              owner: videoDetails["owner"],
              viewsCount: videoDetails["views_count"],
              duration: videoDetails["duration"],
              description: videoDetails['description'],
              uploadDate: (videoDetails["upload_date"] as Timestamp).toDate(),
            ),
          );
        });
      });
    });
  }
}

class VideoCard extends StatelessWidget {
  final VideoModel video;

  VideoCard({this.video});

  @override
  Widget build(BuildContext context) {
    final themex = Theme.of(context);

    return AnimatedCard(
      child: Container(
        margin: EdgeInsets.only(bottom: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFDDDDDD)),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 200,
                  ),
                  Container(
                    padding: EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          child: Text(
                            video.title ?? "NAME NOT AVAILABLE",
                            overflow: TextOverflow.ellipsis,
                            maxLines: 3,
                            softWrap: true,
                            style: themex.textTheme.bodyText1,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 10),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: buttonBoxShadow,
                            ),
                            child: FlatButton(
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                              padding: EdgeInsets.symmetric(
                                vertical: 8,
                                horizontal: 15,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              onPressed: () => _openScreen(
                                context,
                                VideoStreaming(video: video),
                              ),
                              child: Text("Details"),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 4,
                        offset: Offset(0, 2),
                        color: Colors.black.withOpacity(0.1),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: video.thumbnailUrl != null
                        ? Image.network(
                            video.thumbnailUrl,
                            width: double.infinity,
                            height: 200,
                            fit: BoxFit.cover,
                          )
                        : Image.asset(
                            "assets/jpg/ThumbnailNotAvailable.jpg",
                            width: double.infinity,
                            height: 200,
                            fit: BoxFit.cover,
                          ),
                  ),
                ),
                // We set a condition if video URL is not available, then dont show the play button
                Padding(
                  padding: EdgeInsets.only(top: 65),
                  child: Align(
                    alignment: Alignment.center,
                    child: Icon(
                      Icons.play_circle_filled,
                      size: 70,
                      color: Colors.black.withAlpha(100),
                    ),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  _openScreen(context, screenToOpen) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => screenToOpen,
      ),
    );
  }
}
