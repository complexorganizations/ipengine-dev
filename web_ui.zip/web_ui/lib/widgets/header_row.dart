import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../config/assets.dart';

class HeaderRow extends StatelessWidget {
  const HeaderRow({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        InkWell(
          onTap: () {},
          child: RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: 'IPengine.dev\n',
                  style: GoogleFonts.montserrat(
                    color: const Color(0xff000000),
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                    fontSize: 24.0,
                  ),
                ),
                TextSpan(
                  text: 'Innovative Source for IP Address Data',
                  style: GoogleFonts.poppins(
                      color: const Color(0xff999999),
                      fontWeight: FontWeight.w400,
                      fontStyle: FontStyle.normal,
                      fontSize: 12.0),
                ),
              ],
            ),
          ),
        ),
        Spacer(
          flex: 18,
        ),
        _buildColumnHeaderText(
          'Home',
          Icon(
            Icons.location_on_outlined,
            color: Color(0xffF0864B),
          ),
        ),
        Spacer(),
        _buildHeaderText('Pricing'),
        Spacer(),
        _buildHeaderText('Documentaion'),
        Spacer(),
        InkWell(
          onTap: () {},
          child: Container(
            height: 72,
            width: 45,
            child: Image.asset(Assets.avatar),
          ),
        ),
        Spacer(),
      ],
    );
  }

  Widget _buildHeaderText(String text, {bool isTitle = false}) {
    return InkWell(
      onTap: () {},
      child: Text(
        text,
        style: GoogleFonts.montserrat(
          color: isTitle ? const Color(0xff000000) : const Color(0xff555555),
          fontWeight: isTitle ? FontWeight.w600 : FontWeight.w400,
          fontStyle: FontStyle.normal,
          fontSize: isTitle ? 24.0 : 16.0,
        ),
      ),
    );
  }

  Widget _buildColumnHeaderText(
    String text,
    Widget child,
  ) {
    return Column(
      children: [
        child,
        Padding(
          padding: const EdgeInsets.only(
            bottom: 24.0,
          ),
          child: _buildHeaderText(text),
        ),
      ],
    );
  }
}
